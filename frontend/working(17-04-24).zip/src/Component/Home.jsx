import React from 'react'

const Home = () => {
  return (
    <>
     <h2>Welcome to Home component</h2> 
    </>
  )
}

export default Home
