import React, { useEffect, useState } from 'react'
import './Chatbox.css'
import { userlocalStorageData } from '../helper/localStorage';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import FriendsList from './FriendsList';
import UserRequest from './UserRequest';
import io from "socket.io-client";
const ENDPOINT = "http://192.168.0.202:8000";

var socket;

const Chatbox = () => {
  const UserId = userlocalStorageData()
  const [sendMessage, setSendMessage] = useState("");
  const [messages, setMessages] = useState([]);

  const [socketConnected, setSocketConnected] = useState(false);
  const [selectedUser, setSelectedUser] = useState(null);

  //function to set user in chat box 
  const handleUserSelect = (user) => {
    console.log("selected user at chat component", user)
    setSelectedUser(user);
  };

  const [value, setValue] = React.useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  function a11yProps(index) {
    return {
      id: `tab-${index}`,
      'aria-controls': `tabpanel-${index}`,
    };
  }

  function CustomTabPanel(props) {
    const { children, value, index, ...other } = props;

    return (
      <div role="tabpanel" hidden={value !== index} id={`tabpanel-${index}`} {...other}>
        {value === index && (
          <Box sx={{ p: 3 }}>
            <Typography>{children}</Typography>
          </Box>
        )}
      </div>
    );
  }

  //function to send message at onclick
  const handleSendMessage = async (e) => {
    e.preventDefault();
    console.log("sendMessage", sendMessage);
    try {
      const data = {
        content: sendMessage,
        chat: selectedUser
      }
      socket.emit("new message", data);
      setSendMessage('')
    } catch (error) {
      console.log(error)
    }
  }

  //socket logic start here
  useEffect(() => {
    if (selectedUser) {
      socket = io(ENDPOINT);
      socket.emit("setup", selectedUser);
      socket.on("Connected", () => setSocketConnected(true));
    }
  }, [selectedUser]);

  console.log("selectedUser", selectedUser)
  console.log("socketConnected", socketConnected)


  return (
    <>
      <div className="container-fluid main-chatbox">
        <div className="row">

          <div className="col-lg-3 col-md-3 col-sm-3  col-12 chatleftbox border p-0 pt-3" >
            <Box sx={{ width: '100%' }}>
              <Box sx={{ borderBottom: 1, borderColor: 'divider' }} className="d-flex justify-content-center">
                <Tabs value={value} onChange={handleChange} aria-label="basic tabs example">
                  <Tab label="Friend List" {...a11yProps(0)} />
                  <Tab label="User Request" {...a11yProps(1)} />
                </Tabs>
              </Box>
              <CustomTabPanel value={value} index={0}>
                <FriendsList handleUserSelect={handleUserSelect} />
              </CustomTabPanel>
              <CustomTabPanel value={value} index={1}>
                <UserRequest />
              </CustomTabPanel>
            </Box>
          </div>

          <div className="col-lg-9 col-md-9 col-sm-9 col-12 pt-2 pb-3 h-100 chatrightbox border">
            {selectedUser ? (<div className="row">
              <div className="col-12 border-bottom pb-3 pt-2">
                <div className="d-flex justify-content-between flex-wrap">
                  <div className="d-flex justify-content-start flex-wrap gap-2">
                    <div>
                      <img src="https://img.freepik.com/premium-vector/brunette-man-avatar-portrait-young-guy-vector-illustration-face_217290-1549.jpg?w=740" alt="not found" />
                    </div>
                    <div>
                      <h1 className='m-0 mt-2 ms-0 fw-bold' style={{ fontSize: "14px" }}>{selectedUser && selectedUser.firstName + " " + selectedUser.lastName}</h1>
                      <p className='m-0 ms-0 text-success' style={{ fontSize: "14px" }}>Last seen 2 min ago</p>
                    </div>
                  </div>
                  <div className="d-flex justify-content-end align-items-center gap-4">
                    <i className="fa-solid fa-circle-plus"></i>
                    <i className="fa-solid fa-video"></i>
                    <i className="fa-solid fa-expand me-3"></i>
                  </div>
                </div>
              </div>

              <div className="col-12 mt-3 p-0">

                <div className="message-container">
                  <div className='sent-message'>
                    Hello we are testing only
                  </div>
                </div>

                {/* <div className="message-container">
                    {Array.isArray(messages) ? (
                      messages.map((message, index) => (
                        <div key={index} className={parseInt(message.sender_id) === UserId ? 'sent-message' : 'received-message'}>
                          {message.textMessage}
                        </div>
                      ))
                    ) : (
                      <div>No messages are available </div>
                    )}
                  </div> */}

                <div className="col-12 border-top m-0">
                  <form onSubmit={handleSendMessage}>
                    <div className='sendmessage border-0 mt-3 d-flex align-items-center justify-content-between  '>
                      <div className='d-flex gap-2 ms-3'>
                        <div className="pulsicon">
                          <i className="fa-solid fa-plus"></i>
                        </div>
                        <input type="text" placeholder='Type a message here' className='' value={sendMessage} onChange={(e) => setSendMessage(e.target.value)} />
                      </div>

                      <div className='d-flex gap-3 align-items-center me-3'>
                        <i className="fa-regular fa-face-smile"></i>
                        <div className="pulsicon">
                          <button type='submit' className='submitBtn'><i className="fa-solid fa-paper-plane"></i></button>
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>) : (<h1>Plz select User to chat</h1>)}

          </div>
        </div>
      </div>
    </>
  )
}

export default Chatbox  